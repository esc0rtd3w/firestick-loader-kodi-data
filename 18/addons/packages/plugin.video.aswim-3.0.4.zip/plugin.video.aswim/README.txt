plugin.video.aswim
================

Kodi Video Addon for Adult Swim
For Kodi Krypton and above releases

Icon sourced from public domain:
https://en.wikipedia.org/wiki/Adult_Swim#/media/File:AdultSwim.svg

Version 3.0.4 Update for website change
Version 3.0.3 Update for website change
Version 3.0.2 Update for website change
Version 3.0.1 Initial Release

